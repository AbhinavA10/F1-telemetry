﻿namespace F1_Capture
{
    public static class Constants
    {
        public const float Epsilon = 0.00001f;
    }
}
